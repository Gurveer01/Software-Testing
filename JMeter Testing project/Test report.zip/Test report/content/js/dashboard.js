/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Http Request - PUT (Update Book by Id)"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request - DELETE (Delete Book by Id)"], "isController": false}, {"data": [1.0, 500, 1500, "Author Transaction Controller"], "isController": true}, {"data": [1.0, 500, 1500, "Http Request - POST (Create Book)"], "isController": false}, {"data": [1.0, 500, 1500, "Http Request - GET (Get Book by Id)"], "isController": false}, {"data": [1.0, 500, 1500, "Http Request - GET (Get All Books)"], "isController": false}, {"data": [1.0, 500, 1500, "Book Transaction Controller"], "isController": true}, {"data": [1.0, 500, 1500, "HTTP Request - POST (Create Author)"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request - DELETE (Delete Author by Id)"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request - GET (Get Author by Id)"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request - GET (Get All Authors)"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request - PUT (Update Author by Id)"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1000, 0, 0.0, 10.979999999999995, 4, 37, 11.0, 15.0, 16.0, 20.99000000000001, 100.03000900270081, 34.77762078623587, 23.25580486645994], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Http Request - PUT (Update Book by Id)", 100, 0, 0.0, 11.350000000000001, 9, 19, 11.0, 14.0, 15.0, 18.97999999999999, 10.13890297069857, 2.6634422842948395, 4.099126786981649], "isController": false}, {"data": ["HTTP Request - DELETE (Delete Book by Id)", 100, 0, 0.0, 10.77000000000001, 8, 17, 10.0, 13.0, 14.0, 16.97999999999999, 10.150223304912707, 1.8238682501015022, 2.1707997107186356], "isController": false}, {"data": ["Author Transaction Controller", 100, 0, 0.0, 55.49000000000001, 45, 81, 53.0, 66.80000000000001, 75.74999999999994, 81.0, 10.116337885685383, 18.37725641755185, 10.784964592817401], "isController": true}, {"data": ["Http Request - POST (Create Book)", 100, 0, 0.0, 14.780000000000003, 12, 37, 14.0, 18.0, 19.0, 36.83999999999992, 10.111223458038422, 2.5771770728008088, 3.9496966632962587], "isController": false}, {"data": ["Http Request - GET (Get Book by Id)", 100, 0, 0.0, 5.580000000000002, 4, 9, 5.0, 7.0, 8.0, 8.989999999999995, 10.151253679829459, 2.6666867576895745, 1.2887333773220992], "isController": false}, {"data": ["Http Request - GET (Get All Books)", 100, 0, 0.0, 11.830000000000005, 9, 31, 11.0, 14.0, 16.94999999999999, 30.889999999999944, 10.089799212995661, 7.064534513419433, 1.2415182625365755], "isController": false}, {"data": ["Book Transaction Controller", 100, 0, 0.0, 54.31, 44, 108, 52.0, 66.0, 70.94999999999999, 107.66999999999983, 10.053282396702523, 16.68972507414296, 12.654961923192923], "isController": true}, {"data": ["HTTP Request - POST (Create Author)", 100, 0, 0.0, 11.730000000000004, 9, 17, 12.0, 14.0, 15.0, 17.0, 10.163634515702816, 2.1593753176135784, 2.9208538723447504], "isController": false}, {"data": ["HTTP Request - DELETE (Delete Author by Id)", 100, 0, 0.0, 11.100000000000003, 8, 17, 11.0, 13.0, 14.949999999999989, 16.989999999999995, 10.17915309446254, 1.8290665716612378, 2.1201267304560263], "isController": false}, {"data": ["HTTP Request - GET (Get Author by Id)", 100, 0, 0.0, 6.28, 5, 11, 6.0, 8.0, 8.0, 10.989999999999995, 10.180189351521937, 2.2225421205334417, 1.305132087956836], "isController": false}, {"data": ["HTTP Request - GET (Get All Authors)", 100, 0, 0.0, 14.26, 10, 24, 13.0, 18.0, 20.94999999999999, 23.989999999999995, 10.154346060113728, 10.030490803970348, 1.2296278432168968], "isController": false}, {"data": ["HTTP Request - PUT (Update Author by Id)", 100, 0, 0.0, 12.120000000000003, 9, 18, 12.0, 15.0, 15.949999999999989, 18.0, 10.169836265636125, 2.2202818315875112, 3.265868122648225], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1000, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
